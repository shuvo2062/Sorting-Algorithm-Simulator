package algorithmsimulator;

import Gui.UserInterface;

public class AlgorithmSimulator {

    public static void main(String[] args) {
        
        UserInterface myInterface = new UserInterface();
        myInterface.setVisible(true);
    }
}